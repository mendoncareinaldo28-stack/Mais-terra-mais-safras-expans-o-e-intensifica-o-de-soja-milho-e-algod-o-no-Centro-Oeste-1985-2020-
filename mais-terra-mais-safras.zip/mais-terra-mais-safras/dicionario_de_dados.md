# Dicionário de dados

Codificação UTF-8; separador vírgula; decimal ponto; célula vazia = dado não disponível.

## data/pam1612_centro_oeste_uf_1985_2020.csv
| Variável | Unidade | Descrição |
|---|---|---|
| cod_uf | — | Código IBGE da unidade da federação (51 MT, 50 MS, 52 GO, 53 DF) |
| uf | — | Sigla da unidade da federação |
| ano | — | Ano de referência da PAM |
| cultura | — | `soja` (em grão), `milho` (em grão) ou `algodao` (herbáceo, em caroço) |
| area_plantada_ha | ha | Área plantada (SIDRA var. 109); vazia em 1985–1987 |
| area_colhida_ha | ha | Área colhida (SIDRA var. 216) |
| producao_t | t | Quantidade produzida (SIDRA var. 214) |

Goiás em 1985–1988: território atual (sem os municípios do Tocantins). Ver `ajuste_goias_tocantins_1985_1988.csv`.

Indicadores derivados (calculados em `R/01_analises.R`):
- índice de sucessão milho–soja = área colhida de milho / área colhida de soja;
- aproveitamento = Σ área colhida / Σ área plantada das três culturas;
- produtividade = produção / área colhida (kg ha⁻¹);
- participação regional = área colhida no Centro-Oeste / área colhida no Brasil.

## data/pam1612_brasil_1985_2020.csv
ano, cultura, area_colhida_ha, producao_t — totais nacionais da tabela 1612.

## data/ajuste_goias_tocantins_1985_1988.csv
| Variável | Descrição |
|---|---|
| ano, cultura, variavel | Identificação do valor ajustado |
| goias_sidra_uf | Total de Goiás no SIDRA (inclui o atual Tocantins) |
| municipios_atuais_tocantins | Soma dos municípios hoje pertencentes ao Tocantins |
| goias_territorio_atual | Valor usado na análise |

## resultados/
| Arquivo | Conteúdo |
|---|---|
| resultados_numericos.txt | Todos os números citados no artigo |
| aproveitamento_por_uf_1988_2020.csv | Aproveitamento por UF, média e amplitude anuais (cartas de controle) |
| series_regionais_centro_oeste.csv | Séries regionais de área, produção e índice de sucessão |
