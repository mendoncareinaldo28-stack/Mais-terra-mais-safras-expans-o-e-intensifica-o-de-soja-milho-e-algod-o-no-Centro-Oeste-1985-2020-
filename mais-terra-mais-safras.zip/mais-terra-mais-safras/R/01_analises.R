# =============================================================================
# Mais terra, mais safras: expansão e intensificação de soja, milho e algodão
# no Centro-Oeste (1985-2020)
#
# 01_analises.R - reproduz todos os resultados numéricos do artigo:
#   expansão, Mann-Kendall e declive de Sen, ritmo por subperíodo, índice de
#   sucessão milho-soja, reorganização do algodão, participação nacional,
#   produtividade e decomposição logarítmica, cartas de controle (X-barra/R e
#   I-MR), regras de Nelson, Cpk e diagnóstico de autocorrelação.
#
# Uso (na raiz do repositório):  Rscript R/01_analises.R
# Requer apenas R base (testado em R 4.3.3).
# =============================================================================

invisible(Sys.setlocale("LC_CTYPE", "C.UTF-8"))

dados <- read.csv("data/pam1612_centro_oeste_uf_1985_2020.csv", stringsAsFactors = FALSE)
br    <- read.csv("data/pam1612_brasil_1985_2020.csv", stringsAsFactors = FALSE)
dir.create("resultados", showWarnings = FALSE)

culturas <- c("soja", "milho", "algodao")
ufs      <- c("MT", "MS", "GO", "DF")
anos     <- 1985:2020
saida    <- file("resultados/resultados_numericos.txt", open = "wt", encoding = "UTF-8")
out <- function(...) { txt <- sprintf(...); cat(txt, "\n"); writeLines(txt, saida) }

# ---------------------------------------------------------------- funções ----
mann_kendall <- function(x) {
  n <- length(x); s <- 0
  for (i in 1:(n - 1)) for (j in (i + 1):n) s <- s + sign(x[j] - x[i])
  t <- table(x)
  var_s <- (n * (n - 1) * (2 * n + 5) - sum(t * (t - 1) * (2 * t + 5))) / 18
  z <- if (s > 0) (s - 1) / sqrt(var_s) else if (s < 0) (s + 1) / sqrt(var_s) else 0
  list(tau = s / (n * (n - 1) / 2), z = z, p = 2 * (1 - pnorm(abs(z))))
}
sen <- function(x) {
  n <- length(x); d <- c()
  for (i in 1:(n - 1)) for (j in (i + 1):n) d <- c(d, (x[j] - x[i]) / (j - i))
  median(d)
}
# Regras de Nelson usadas no artigo (R1-R4); devolve lista de índices violados
nelson <- function(x, lc, sigma) {
  z <- (x - lc) / sigma; n <- length(z)
  r1 <- which(abs(z) > 3)
  r2 <- r3 <- r4 <- integer(0)
  for (i in 3:n) { w <- z[(i - 2):i]
    if (sum(w > 2) >= 2 || sum(w < -2) >= 2) r2 <- c(r2, i) }
  for (i in 5:n) { w <- z[(i - 4):i]
    if (sum(w > 1) >= 4 || sum(w < -1) >= 4) r3 <- c(r3, i) }
  for (i in 8:n) { w <- z[(i - 7):i]
    if (all(w > 0) || all(w < 0)) r4 <- c(r4, i) }
  list(R1 = r1, R2 = unique(r2), R3 = sort(unique(r3)), R4 = sort(unique(r4)))
}

# --------------------------------------------------------- séries regionais --
reg <- aggregate(cbind(area_colhida_ha, producao_t) ~ ano + cultura, data = dados, FUN = sum)
serie <- function(cul, var = "area_colhida_ha") {
  s <- reg[reg$cultura == cul, ]; s[order(s$ano), var]
}
tot <- serie("soja") + serie("milho") + serie("algodao")
out("== Expansão (área colhida, Mha) ==")
out("Três culturas: %.2f -> %.2f (x%.1f)", tot[1] / 1e6, tot[36] / 1e6, tot[36] / tot[1])
for (c in culturas) { a <- serie(c)
  out("  %-8s %.2f -> %.2f Mha (%+.0f%%)", c, a[1] / 1e6, a[36] / 1e6, (a[36] / a[1] - 1) * 100) }

soja_uf <- function(u) dados$area_colhida_ha[dados$uf == u & dados$cultura == "soja"]
out("Soja 1985: MS %.2f Mha, MT %.2f Mha; razão MT/MS em 2020 = %.1f",
    soja_uf("MS")[1] / 1e6, soja_uf("MT")[1] / 1e6, soja_uf("MT")[36] / soja_uf("MS")[36])

out("\n== Mann-Kendall e Sen (área colhida, mil ha/ano) ==")
for (c in culturas) {
  mk <- mann_kendall(serie(c))
  out("CO %-8s tau=%.3f p=%.1e Sen=%.1f", c, mk$tau, mk$p, sen(serie(c)) / 1000)
  for (u in ufs) {
    x <- dados$area_colhida_ha[dados$uf == u & dados$cultura == c]
    if (sum(x, na.rm = TRUE) == 0) next
    mk <- mann_kendall(x)
    out("   %s tau=%6.3f p=%.3g Sen=%7.1f", u, mk$tau, mk$p, sen(x) / 1000)
  }
}

out("\n== Ritmo de expansão por subperíodo (mil ha/ano) ==")
per <- list(c(1985, 1995), c(1995, 2005), c(2005, 2015), c(2015, 2020))
for (p in per) {
  i <- p - 1984; dt <- diff(p)
  out("%d-%d: total %.1f | soja %.1f | milho %.1f | algodão %.1f", p[1], p[2],
      diff(tot[i]) / dt / 1e3, diff(serie("soja")[i]) / dt / 1e3,
      diff(serie("milho")[i]) / dt / 1e3, diff(serie("algodao")[i]) / dt / 1e3)
}

# -------------------------------------------------- índice de sucessão ------
isms <- serie("milho") / serie("soja")
out("\n== Índice de sucessão milho-soja ==")
out("CO: 1985 %.2f; máximo 1985-1990 %.2f (%d); mínimo %.2f (%d); 2020 %.2f",
    isms[1], max(isms[1:6]), anos[which.max(isms[1:6])], min(isms), anos[which.min(isms)], isms[36])
for (u in c("MT", "MS", "GO")) {
  m <- dados$area_colhida_ha[dados$uf == u & dados$cultura == "milho"]
  s <- dados$area_colhida_ha[dados$uf == u & dados$cultura == "soja"]
  out("  %s 2020: %.2f", u, m[36] / s[36])
}
mk <- mann_kendall(isms[22:36]); out("Tendência 2006-2020: tau=%.3f p=%.1e", mk$tau, mk$p)

# ------------------------------------------------------ algodão por UF ------
alg <- function(u) dados$area_colhida_ha[dados$uf == u & dados$cultura == "algodao"]
out("\n== Algodão: participação na área regional (%%) ==")
for (y in c(1985, 2000, 2020)) { i <- y - 1984
  out("%d: MT %.1f | MS %.1f | GO %.1f", y, 100 * alg("MT")[i] / serie("algodao")[i],
      100 * alg("MS")[i] / serie("algodao")[i], 100 * alg("GO")[i] / serie("algodao")[i]) }
out("Variação 1985-2020: MS %.1f%% | GO %.1f%% | MT %.1f -> %.1f mil ha",
    100 * (alg("MS")[36] / alg("MS")[1] - 1), 100 * (alg("GO")[36] / alg("GO")[1] - 1),
    alg("MT")[1] / 1e3, alg("MT")[36] / 1e3)

out("\n== Participação do Centro-Oeste na área colhida nacional (%%) ==")
for (c in culturas) { b <- br$area_colhida_ha[br$cultura == c]
  out("%-8s 1985 %.1f -> 2020 %.1f", c, 100 * serie(c)[1] / b[1], 100 * serie(c)[36] / b[36]) }

# ------------------------------------- produtividade e decomposição ---------
out("\n== Produtividade (kg/ha) e decomposição logarítmica ==")
for (c in culturas) {
  a <- serie(c); p <- serie(c, "producao_t"); r <- p / a * 1000
  mk <- mann_kendall(r)
  da <- log(a[36] / a[1]); dr <- log(r[36] / r[1])
  out("%-8s %.0f -> %.0f (%+.0f%%); Sen %.1f kg/ha/ano; MK p=%.1e; produção x%.1f; área %.1f%% | produtividade %.1f%%",
      c, r[1], r[36], 100 * (r[36] / r[1] - 1), sen(r), mk$p, p[36] / p[1],
      100 * da / (da + dr), 100 * dr / (da + dr))
}
for (c in c("soja", "milho")) {
  r <- sapply(c("MT", "MS", "GO"), function(u) {
    d <- dados[dados$uf == u & dados$cultura == c & dados$ano == 2020, ]
    d$producao_t / d$area_colhida_ha * 1000 })
  out("%s 2020 por UF: %s; amplitude relativa %.1f%%", c,
      paste(sprintf("%s=%.0f", names(r), r), collapse = " "), 100 * (max(r) / min(r) - 1))
}

# ----------------------------------- carta X-barra/R do aproveitamento ------
cep <- dados[dados$ano >= 1988, ]
ap  <- aggregate(cbind(area_colhida_ha, area_plantada_ha) ~ ano + uf, data = cep, FUN = sum)
ap$aprov <- ap$area_colhida_ha / ap$area_plantada_ha
mat <- reshape(ap[, c("ano", "uf", "aprov")], idvar = "ano", timevar = "uf", direction = "wide")
mat <- mat[order(mat$ano), ]
X <- as.matrix(mat[, -1]); anos_cep <- mat$ano
xbar <- rowMeans(X); R <- apply(X, 1, function(v) diff(range(v)))
A2 <- 0.729; D3 <- 0; D4 <- 2.282; d2 <- 2.059
LC <- mean(xbar); Rbar <- mean(R)
LIC <- LC - A2 * Rbar; LSC <- LC + A2 * Rbar
sig_xbar <- (A2 * Rbar) / 3
out("\n== Carta de médias do aproveitamento (1988-2020, n = 4) ==")
out("LC = %.4f; LIC = %.4f; LSC = %.4f", LC, LIC, LSC)
nr <- nelson(xbar, LC, sig_xbar)
for (r in names(nr)) out("  %s: %s", r, paste(anos_cep[nr[[r]]], collapse = ", "))
for (y in anos_cep[nr$R1]) out("  %d: média %.4f", y, xbar[anos_cep == y])
out("Carta de amplitudes: LC = %.4f; LSC = %.4f; acima do LSC: %s", Rbar, D4 * Rbar,
    paste(anos_cep[R > D4 * Rbar], collapse = ", "))
out("Aproveitamento médio 2012-2020 = %.4f", mean(xbar[anos_cep >= 2012]))
sig_ind <- Rbar / d2
out("Cpk (LIE = 0,95) = %.2f  [sigma = Rbar/d2 = %.5f]", (LC - 0.95) / (3 * sig_ind), sig_ind)
write.csv(data.frame(ano = anos_cep, round(X, 5), media = round(xbar, 5), amplitude = round(R, 5)),
          "resultados/aproveitamento_por_uf_1988_2020.csv", row.names = FALSE)

# ------------------------------- carta I-MR da taxa de expansão da soja -----
soja <- serie("soja")
taxa <- 100 * diff(soja) / head(soja, -1)
MR <- abs(diff(taxa)); s_imr <- mean(MR) / 1.128
LCi <- mean(taxa)
out("\n== Carta I-MR da taxa anual de variação da área de soja (%%) ==")
out("LC = %.2f; LIC = %.2f; LSC = %.2f; sigma = %.1f p.p.; n = %d",
    LCi, LCi - 3 * s_imr, LCi + 3 * s_imr, s_imr, length(taxa))
ni <- nelson(taxa, LCi, s_imr)
out("Violações: %s", paste(sprintf("%s=[%s]", names(ni), sapply(ni, function(v) paste(anos[-1][v], collapse = ","))), collapse = " "))
out("Maior crescimento %.1f%% (%d); maior retração %.1f%% (%d)",
    max(taxa), anos[-1][which.max(taxa)], min(taxa), anos[-1][which.min(taxa)])

# ----------------------------------------- diagnóstico de autocorrelação ----
out("\n== Autocorrelação (lag 1) e teste de Ljung-Box (lag 1) ==")
diag_ac <- function(x, nome) {
  r1 <- acf(x, plot = FALSE, lag.max = 1)$acf[2]
  lb <- Box.test(x, lag = 1, type = "Ljung-Box")
  out("%-40s r1 = %6.3f; Ljung-Box p = %.3g", nome, r1, lb$p.value)
}
diag_ac(soja, "Área de soja (nível)")
diag_ac(taxa, "Taxa anual de variação da soja")
diag_ac(xbar, "Aproveitamento médio anual (1988-2020)")

# --------------------------------------- séries para as figuras -------------
fig <- data.frame(ano = anos,
                  soja_ha = serie("soja"), milho_ha = serie("milho"), algodao_ha = serie("algodao"),
                  soja_t = serie("soja", "producao_t"), milho_t = serie("milho", "producao_t"),
                  algodao_t = serie("algodao", "producao_t"), indice_sucessao_co = round(isms, 4))
write.csv(fig, "resultados/series_regionais_centro_oeste.csv", row.names = FALSE)
close(saida)
