# =============================================================================
# 02_figuras.R - gera as Figuras 1, 2 e 3 do artigo em PNG (300 dpi) e PDF
# (vetorial). Rode depois de 01_analises.R.
#
# Uso (na raiz do repositório):  Rscript R/02_figuras.R
# =============================================================================
invisible(Sys.setlocale("LC_CTYPE", "C.UTF-8"))
options(OutDec = ",")

dados <- read.csv("data/pam1612_centro_oeste_uf_1985_2020.csv", stringsAsFactors = FALSE)
dir.create("figuras", showWarnings = FALSE)
anos <- 1985:2020
LARG <- 6.9; DPI <- 300                       # 6,9 pol = 2.070 px a 300 dpi
fmt <- function(x) formatC(x, format = "f", digits = 4, decimal.mark = ",")
cinza <- c("#1a1a1a", "#6e6e6e", "#a8a8a8", "#d4d4d4")

reg <- aggregate(cbind(area_colhida_ha, producao_t) ~ ano + cultura, data = dados, FUN = sum)
serie <- function(cul, var = "area_colhida_ha", uf = NULL) {
  d <- if (is.null(uf)) reg else aggregate(cbind(area_colhida_ha, producao_t) ~ ano + cultura,
                                           data = dados[dados$uf == uf, ], FUN = sum)
  d <- d[d$cultura == cul, ]; d[order(d$ano), var]
}
abre <- function(nome, alt) {
  list(png = function() png(file.path("figuras", paste0(nome, ".png")), width = LARG, height = alt,
                            units = "in", res = DPI, type = "cairo"),
       pdf = function() cairo_pdf(file.path("figuras", paste0(nome, ".pdf")), width = LARG, height = alt))
}
desenha <- function(nome, alt, f) for (dev in abre(nome, alt)) { dev(); f(); invisible(dev.off()) }

# ------------------------------------------------------------ Figura 1 ------
fig1 <- function() {
  par(mfrow = c(1, 2), mar = c(4.2, 4.2, 2.2, 0.8), mgp = c(2.6, 0.7, 0), cex = 0.8, las = 1)
  ic  <- serie("milho") / serie("soja")
  imt <- serie("milho", uf = "MT") / serie("soja", uf = "MT")
  ims <- serie("milho", uf = "MS") / serie("soja", uf = "MS")
  plot(anos, ic, type = "n", ylim = c(0, 1.0), xlab = "Ano",
       ylab = expression("Área"[milho] / "Área"[soja]), main = "(a) Índice de sucessão milho–soja",
       font.main = 1)
  abline(h = seq(0, 0.8, 0.1), col = "grey92")
  lines(anos, ims, lwd = 1.6, lty = 2, col = cinza[3])
  lines(anos, imt, lwd = 1.6, lty = 2, col = cinza[1])
  lines(anos, ic, lwd = 2.2, col = cinza[1]); points(anos, ic, pch = 16, cex = 0.5)
  legend("topleft", c("Centro-Oeste", "Mato Grosso", "Mato Grosso do Sul"), lty = c(1, 2, 2),
         lwd = c(2.2, 1.6, 1.6), col = cinza[c(1, 1, 3)], bty = "n", cex = 0.75, seg.len = 2.2,
         bg = "white")
  ufs <- c("MT", "MS", "GO", "DF")
  A <- sapply(ufs, function(u) serie("algodao", uf = u))
  P <- 100 * A / rowSums(A)
  cum <- t(apply(P, 1, cumsum))
  plot(anos, cum[, 4], type = "n", ylim = c(0, 112), yaxt = "n", xlab = "Ano",
       ylab = "Participação na área de algodão (%)", main = "(b) Distribuição do algodão", font.main = 1)
  axis(2, at = seq(0, 100, 20))
  low <- rep(0, length(anos))
  for (k in 1:4) {
    polygon(c(anos, rev(anos)), c(cum[, k], rev(low)), col = cinza[k], border = NA)
    low <- cum[, k]
  }
  legend("top", ufs, fill = cinza, border = NA, bty = "n", ncol = 4, cex = 0.75, x.intersp = 0.4)
}
desenha("figura1_sucessao_algodao", 3.4, fig1)

# ------------------------------------------------------------ Figura 2 ------
fig2 <- function() {
  par(mfrow = c(1, 2), mar = c(4.2, 4.4, 2.2, 0.8), mgp = c(2.8, 0.7, 0), cex = 0.8, las = 1)
  r <- sapply(c("soja", "milho", "algodao"), function(c) serie(c, "producao_t") / serie(c) * 1000)
  plot(anos, r[, 2], type = "n", ylim = c(1000, 7400), xlab = "Ano",
       ylab = expression("Produtividade (kg ha"^-1 * ")"), main = "(a) Produtividade média regional",
       font.main = 1)
  abline(h = seq(1000, 7000, 1000), col = "grey92")
  lines(anos, r[, 1], lwd = 2, col = cinza[2]); lines(anos, r[, 2], lwd = 2, col = cinza[3])
  lines(anos, r[, 3], lwd = 2, col = cinza[1])
  legend("topleft", c("Soja", "Milho", "Algodão em caroço"), lwd = 2, col = cinza[c(2, 3, 1)],
         bty = "n", cex = 0.8)
  dec <- sapply(c("soja", "milho", "algodao"), function(c) {
    a <- serie(c); p <- serie(c, "producao_t"); y <- p / a
    da <- log(a[36] / a[1]); dr <- log(y[36] / y[1]); 100 * c(da, dr) / (da + dr) })
  colnames(dec) <- c("Soja", "Milho", "Algodão")
  b <- barplot(dec, col = cinza[c(4, 1)], border = NA, ylim = c(0, 118), yaxt = "n",
               ylab = "Contribuição ao crescimento (%)", main = "(b) Decomposição do crescimento",
               font.main = 1)
  axis(2, at = seq(0, 100, 20))
  text(b, dec[1, ] / 2, sprintf("%.0f%%", dec[1, ]), cex = 0.85)
  text(b, dec[1, ] + dec[2, ] / 2, sprintf("%.0f%%", dec[2, ]), col = "white", cex = 0.85)
  legend("top", c("Área colhida", "Produtividade"), fill = cinza[c(4, 1)], border = NA,
         bty = "n", ncol = 2, cex = 0.78, x.intersp = 0.5)
}
desenha("figura2_produtividade_decomposicao", 3.4, fig2)

# ------------------------------------------------------------ Figura 3 ------
fig3 <- function() {
  cep <- dados[dados$ano >= 1988, ]
  ap  <- aggregate(cbind(area_colhida_ha, area_plantada_ha) ~ ano + uf, data = cep, FUN = sum)
  ap$aprov <- ap$area_colhida_ha / ap$area_plantada_ha
  X <- tapply(ap$aprov, list(ap$ano, ap$uf), identity)
  yr <- as.integer(rownames(X)); xb <- rowMeans(X); R <- apply(X, 1, function(v) diff(range(v)))
  LC <- mean(xb); Rb <- mean(R); LIC <- LC - 0.729 * Rb; LSC <- LC + 0.729 * Rb; LSCr <- 2.282 * Rb
  s <- 0.729 * Rb / 3
  par(mfrow = c(2, 1), mar = c(3.0, 4.4, 2, 6.2), mgp = c(2.6, 0.7, 0), cex = 0.8, las = 1)
  # (a) carta de médias
  plot(yr, xb, type = "n", ylim = c(0.972, 1.010), xlab = "", ylab = "Aproveitamento",
       main = "(a) Carta de médias (subgrupos anuais, n = 4 UF)", font.main = 1)
  abline(h = LC + c(-2, -1, 1, 2) * s, col = "grey80", lty = 3)
  abline(h = c(LIC, LSC), lty = 2, lwd = 1.4); abline(h = LC, lwd = 1.4, col = cinza[2])
  lines(yr, xb, col = cinza[2]); points(yr, xb, pch = 16, cex = 0.6)
  out <- xb < LIC | xb > LSC
  points(yr[out], xb[out], pch = 16, cex = 1.5)
  text(yr[out], xb[out], yr[out], pos = 1, offset = 0.8, cex = 0.8)
  r3 <- yr >= 2014
  points(yr[r3], xb[r3], pch = 1, cex = 1.5)
  legend("bottomright", c("Violação da regra R1", "Regra R3 (2014-2020)"), pch = c(16, 1),
         pt.cex = c(1.3, 1.3), bty = "n", cex = 0.72, horiz = TRUE)
  usr <- par("usr")
  mtext(paste(c("LSC =", "LC =", "LIC ="), fmt(c(LSC, LC, LIC))), side = 4, at = c(LSC, LC, LIC),
        line = 0.3, cex = 0.75, las = 1)
  # (b) carta de amplitudes
  par(mar = c(4.0, 4.4, 2, 6.2))
  plot(yr, R, type = "n", ylim = c(0, 0.088), xlab = "Ano", ylab = "Amplitude (R)",
       main = "(b) Carta de amplitudes (dispersão entre UF)", font.main = 1)
  abline(h = LSCr, lty = 2, lwd = 1.4); abline(h = Rb, lwd = 1.4, col = cinza[2])
  lines(yr, R, col = cinza[2]); points(yr, R, pch = 16, cex = 0.6)
  o <- R > LSCr
  points(yr[o], R[o], pch = 16, cex = 1.5)
  text(yr[o], R[o], yr[o], pos = 3, offset = 0.8, cex = 0.8)
  mtext(paste(c("LSC =", "LC ="), fmt(c(LSCr, Rb))), side = 4, at = c(LSCr, Rb), line = 0.3,
        cex = 0.75, las = 1)
}
desenha("figura3_cartas_controle", 5.0, fig3)
cat("Figuras gravadas em figuras/ (PNG 300 dpi e PDF)\n")
