# Mais terra, mais safras 🌱

Dados e scripts em R do artigo **"Mais terra, mais safras: expansão e intensificação de soja, milho e algodão no Centro-Oeste (1985–2020)"**.

O Centro-Oeste concentra a maior fronteira agrícola tropical do planeta. Entre 1985 e 2020, a área colhida de soja, milho e algodão
na região cresceu 6,7 vezes, de 4,0 para 27,1 milhões de hectares. Este repositório reúne as séries anuais por unidade da federação e o código
que mede essa expansão com estatísticas públicas do IBGE, sem classificação de imagens: tendências, intensificação por dupla safra,
reorganização espacial do algodão e auditoria da série por controle estatístico de processo (CEP).

**Principais resultados**
- A expansão de área explicou 68% a 75% do crescimento da produção; a produtividade, 25% a 32%.
- O índice de sucessão milho–soja caiu até 2005 (0,20) e subiu de forma contínua até 2020 (0,54): a virada da expansão horizontal para a dupla safra.
- O algodão migrou quase todo para Mato Grosso (de 11,5% para 94,2% da área regional).
- As cartas de controle apontaram 1990, 2000 e 2016 como anos de perturbação e uma melhoria sustentada do aproveitamento a partir de 2014 (Cpk = 1,84).

## Conteúdo

```
data/
  pam1612_centro_oeste_uf_1985_2020.csv       MT, MS, GO e DF × soja, milho e algodão × 36 anos (432 linhas)
  pam1612_brasil_1985_2020.csv                Totais nacionais (participação regional)
  ajuste_goias_tocantins_1985_1988.csv        Ajuste territorial de Goiás (ver abaixo)
R/
  01_analises.R                               Todos os resultados numéricos do artigo
  02_figuras.R                                Figuras 1, 2 e 3 (PNG 300 dpi e PDF vetorial)
resultados/                                   Saídas do 01_analises.R
figuras/                                      Saídas do 02_figuras.R
dicionario_de_dados.md                        Descrição das variáveis
```

## Como reproduzir

Requer apenas o R base (testado em R 4.3.3). Na raiz do repositório:

```bash
Rscript R/01_analises.R   # gera resultados/resultados_numericos.txt e as tabelas
Rscript R/02_figuras.R    # gera as figuras
```

## Fonte dos dados

IBGE, Produção Agrícola Municipal (PAM), tabela 1612 do SIDRA (https://sidra.ibge.gov.br/tabela/1612), consultada em outubro de 2026:
área plantada (var. 109), área colhida (var. 216) e quantidade produzida (var. 214) de soja (em grão), milho (em grão) e algodão herbáceo (em caroço).

### Ajuste territorial de Goiás (1985–1988)

Até 1988, o Tocantins fazia parte de Goiás, e os totais estaduais do SIDRA para Goiás nesses anos incluem o território tocantinense.
Para manter a região com os limites atuais (467 municípios), subtraíram-se dos totais de Goiás os valores dos municípios que hoje
pertencem ao Tocantins (SIDRA, nível municipal). O arquivo `ajuste_goias_tocantins_1985_1988.csv` mostra o valor original, o valor
subtraído e o valor usado. Sem esse ajuste, a área de soja de 1985 seria de 2,88 Mha (e não 2,84) e a de milho, de 1,12 Mha (e não 1,05).

### Convenções

No SIDRA, "-" significa zero e "..." significa dado não disponível. Nos CSV, "-" virou **0** e "..." virou **célula vazia**.
A área plantada só existe a partir de 1988 para as quatro unidades; por isso o aproveitamento e as cartas de controle cobrem 1988–2020.

### Conferência com o artigo

Os scripts reproduzem os valores do artigo, inclusive as cartas de controle (LC = 0,9942; LIC = 0,9822; LSC = 1,0062; R̄ = 0,0165),
o Cpk de 1,84 e a carta I-MR da soja (LC = 5,71%; limites de −20,45% e 31,87%). Pequenas diferenças de arredondamento, atribuíveis
à agregação municipal usada no artigo, aparecem em três valores: declive de Sen da soja (422,8 contra 422,5 mil ha/ano), expansão média
em 1985–1995 e 2015–2020 (250,6 e 1.011,2 contra 250,7 e 1.010,5 mil ha/ano) e crescimento do algodão (+720% contra +721%).

## Como citar

> Autores (2026). *Mais terra, mais safras — dados e scripts* [Conjunto de dados]. GitHub/Zenodo. https://doi.org/10.5281/zenodo.XXXXXXX

Artigo: *[referência e DOI após a publicação]*

## Licença

Dados: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.pt_BR). Código: MIT. Ver `LICENSE`.
